import automaton.Monitor;
import gov.nasa.ltl.graph.Graph;
import gov.nasa.ltl.graph.Guard;
import gov.nasa.ltl.graph.Literal;
import gov.nasa.ltl.graph.Node;
import gov.nasa.ltl.trans.ParseErrorException;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

import static gov.nasa.ltl.trans.LTL2Buchi.translate;

public class Main {
    public static void main(String[] args) {
        Monitor<String> monitor = getMonitor("g");

        Monitor<String> monitor_copy;
        try {
            saveMonitor(monitor, "monitor.bin");

            monitor_copy = loadMonitor("monitor.bin");
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        assert monitor_copy != null;
        monitor_copy.addObserver(accept -> System.out.println(accept ? "A tulajdonság teljesült." : "A tulajdonság sérült."));
        monitor_copy.move(makeEvent(new Literal<>("g", false))); //negated = false
    }

    @SafeVarargs
    private static Guard<String> makeEvent(Literal<String>... literals) {
        Guard<String> result = new Guard<>();
        result.addAll(Arrays.asList(literals));
        return result;
    }

    private static Monitor<String> loadMonitor(String file) throws IOException, ClassNotFoundException {
        Monitor<String> monitor11;
        FileInputStream fileInputStream
                = new FileInputStream(file);
        ObjectInputStream objectInputStream
                = new ObjectInputStream(fileInputStream);
        //noinspection unchecked
        monitor11 = (Monitor<String>) objectInputStream.readObject();
        objectInputStream.close();
        return monitor11;
    }

    private static void saveMonitor(Monitor<String> monitor, String file) throws IOException {
        FileOutputStream fileOutputStream
                = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream
                = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(monitor);
        objectOutputStream.flush();
        objectOutputStream.close();
    }

    private static Monitor<String> getMonitor(String property) {
        Graph<String> g_accept;
        Graph<String> g_reject;
        try {
            g_accept = translate(property, true, true, true);
            g_reject = translate("!(%s)".formatted(property), true, true, true);
        } catch (ParseErrorException e) {
            throw new RuntimeException(e);
        }
        for (Node<String> node : new ArrayList<Node<String>>(){{addAll(g_reject.getNodes()); addAll(g_accept.getNodes());}}) {
            node.setBooleanAttribute("accepting", true);
        }
        return new Monitor<>(g_accept, g_reject);
    }
}