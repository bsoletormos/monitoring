package automaton;

import gov.nasa.ltl.graph.*;

import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Monitor<PropT> implements Serializable {
    Graph<PropT> accepting_graph;
    Graph<PropT> rejecting_graph;

    class Automaton extends HashMap<Node<PropT>, Boolean> {
        public Set<Node<PropT>> nextStates(Collection<Literal<PropT>> event) {
            return entrySet().stream()
                    .filter(Map.Entry::getValue)
                    .map(Map.Entry::getKey)
                    .flatMap(node -> node.getOutgoingEdges().stream())
                    .filter(edge -> edge.getGuard().subtermOf(new Guard<>(event)))
                    .map(Edge::getNext)
                    .collect(Collectors.toSet());
        }

        public void setStates(Set<Node<PropT>> nextStates) {
            keySet().forEach(node -> put(node, nextStates.contains(node)));
        }
    }
    enum AutomatonID {ACCEPTING, REJECTING}
    Map<AutomatonID, Automaton> automata = new HashMap<>();
    {
        automata.put(AutomatonID.ACCEPTING, new Automaton());
        automata.put(AutomatonID.REJECTING, new Automaton());
    }

    public Monitor(Graph<PropT> accepting_graph, Graph<PropT> rejecting_graph) {
        this.accepting_graph = accepting_graph;
        this.rejecting_graph = rejecting_graph;
        setAutomataToInitialState();
    }

    //move, transition, step or advance
    public void move(Collection<Literal<PropT>> event) {
        automata.values().forEach(automaton -> automaton.setStates(automaton.nextStates(event)));
        long accepting_automata_active_count = automata.get(AutomatonID.ACCEPTING).values().stream().filter(Boolean::booleanValue).count();
        long rejecting_automata_active_count = automata.get(AutomatonID.REJECTING).values().stream().filter(Boolean::booleanValue).count();
        if (accepting_automata_active_count == 0) {
            notifyObservers(false);
        } else if (rejecting_automata_active_count == 0) {
            notifyObservers(true);
        }
    }

    transient List<Consumer<Boolean>> observers = new ArrayList<>();
    public void addObserver(Consumer<Boolean> observer) {
        observers.add(observer);
    }
    public void removeObserver(Consumer<Boolean> observer) {
        observers.remove(observer);
    }
    void notifyObservers(boolean accept) {
        observers.forEach(observer -> observer.accept(accept));
    } //accept = true, elfogadta az automata. accept=false: sérült a property

    void setAutomataToInitialState() {
        for (Node<PropT> node : accepting_graph.getNodes()) {
            automata.get(AutomatonID.ACCEPTING).put(node, node == accepting_graph.getInit());
        }
        for (Node<PropT> node : rejecting_graph.getNodes()) {
            automata.get(AutomatonID.REJECTING).put(node, node == rejecting_graph.getInit());
        }
    }

    private void readObject(java.io.ObjectInputStream in)
            throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        observers = new ArrayList<>();
    }
}
