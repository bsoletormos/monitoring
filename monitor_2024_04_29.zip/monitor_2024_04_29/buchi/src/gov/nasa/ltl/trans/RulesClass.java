//
// Copyright (C) 2006 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
// 
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
// 
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//
package gov.nasa.ltl.trans;

/**
 * Default {@link Rewriter} rules.
 * @author ckong - Sept 7, 2001
 */
public class RulesClass {
  public static String getRules () {
    return """
            p/\\p
            p

            p/\\true
            p

            p/\\false
            false

            p/\\!p
            false

            p\\/p
            p

            p\\/true
            true

            p\\/false
            p

            p\\/!p
            true

            ( X p ) U ( X q )
            X ( p U q )

            ( p V q ) /\\ ( p V r )
            p V ( q /\\ r )

            ( p V r ) \\/ ( q V r )
            ( p \\/ q ) V r

            ( X p ) /\\ ( X q )
            X ( p /\\ q )

            X true
            true

            p U false
            false

            [] <> p \\/ [] <> q
            [] <> ( p \\/ q )

            <> X p
            X <> p

            [] [] <> p
            [] <> p

            <> [] <> p
            [] <> p

            X [] <> p
            [] <> p

            <> ( p /\\ [] <> q )
            ( <> p ) /\\ ( [] <> q )

            [] ( p \\/ [] <> q )
            ( [] p ) \\/ ( [] <> q )

            X ( p /\\ [] <> q )
            ( X p ) /\\ ( [] <> q )

            X ( p \\/ [] <> q )
            ( X p ) \\/ ( [] <> q )""";
  }

  public static void main (String[] args) {
    System.out.println(getRules());
  }
}
