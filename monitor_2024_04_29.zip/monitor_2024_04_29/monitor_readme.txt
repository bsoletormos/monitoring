TARTALOM:
monitor_readme.txt
monitoring/src/
monitoring/out/artifacts/monitoring.jar
monitroing/out/production/monitoring/ (class file-ok)
buchi/ltl2buchi_Readme.txt (Leírja a tulajdonságok elvárt alakját.)
buchi/src/
buchi/ltl2buchi.jar
buchi/build/gov/nasa/ltl/ (class file-ok)

===========================================================================
monitoring/monitoring/Main.class - demó program

1. Az program beolvassa a tulajdonságot. Elkészíti a monitort.
	Használhatunk --verbose kapcsolót.

2. Ha használtuk a --verbose kapcsolót:
	Ekkor a program zárójelezve kiírja az eredeti és a negált tulajdonságot; end_of_trace jellel és anélkül is.
	Kiírja a hozzájuk tartozó Büchi automatákat is.

3. A program eseményt/eseményeket olvas be.
	Szóközzel elválasztva lehet az aktív jeleket megadni.
	{}-párok közt több eseményt is meg lehet adni.
	end_of_trace jellel lehet az eseménysorozat végét jelölni. (Az igazi magyaros kifejezés a 'trace'-re pillanatnyilag nem jut eszembe :[ )

4. A program egyenként átadja az eseményeket a monitornak.
	Ha több eseményt is megadtunk, vagy a verbose mód be van kapcsolva: sorról sorra kiírja, hogy melyik eseménynél tart.
	Ha valamelyik jel nem szerepel a monitorban, akkor a monitor jelzi azt.
	Ha a --verbose be van kapcsolva, akkor a program kiírja az automaták aktív állapotait. (Más szóval az aktív csomópontokat.)
	Ha a tulajdonság teljesült vagy sérült, akkor a program kiírja ezt, és ki fog lépni.
	Ha a program beolvasta az end_of_trace-t akkor végül kilép.

===========================================================================

Monitor készítése pl. []g tulajdonsággal:
Monitor m = Monitor.getMonitor("[]g");

>Az ltl2buchi által elvárt formában kell megadni.

Feliratkozás a tulajdonság teljesülésére. Pl. kiíratjuk, hogy a tulajdonság teljesült:
m.acceptObservers.add(() -> System.out.println("A tulajdonság teljesült."));

>Tulajdonság sérüléséhez: m.rejectObservers

Event megadása, és monitor léptetése. Pl. g és end_of_trace:
m.move("g end_of_trace");
~~~~~~~~~~^
Az end_of_trace egy beépített jel. Eddig kell az ALWAYS, UNTIL és EVENTUALLY típusú követelményeknek teljesülniük.
Az eventeket szóközzel kell elválasztani.
A fölös szóközöket figyelmen kívül hagyja a program.

Több event megadása:
m.move("{g} {g end_of_trace}");

m.setAutomataToInitialState();
~~^ Visszaállítja az automaták kiinduló állapotát. (Mintha nem lett volna eddig 'move' hívás.)

Monitor.saveMonitor(m, "monitor.bin");
~~~~~~~~^ Az adott monitort az adott fájlba menti.

Monitor betöltése adott fájlból:
Monitor m = Monitor.loadMonitor("monitor.bin");

====================================================================================

amit az ltl2buchi-ben változtattam:
 - extra konstuktor a Guard-nak
 - Graph és tagjai: Seriablizable
 - G ψ ≡ false R ψ HELYETT G ψ ≡ end_of_trace R ψ
 - F ψ ≡ true U ψ HELYETT F ψ ≡ !end_of_trace U ψ
 - ψ U φ HELYETT !end_of_trace ψ ∧ !end_of_trace U φ