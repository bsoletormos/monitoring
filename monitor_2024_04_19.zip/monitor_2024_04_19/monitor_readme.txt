src: a monitor kód
monitoring.jar: a hozzá tartozó jar
/monitoring/: lefordított fájlok, demó program
ltl2buchi.jar: ha fordításhoz kellene
ltl2buchi_Readme.txt: leírja a tulajdonságok elvárt formátumát.

===========================================================================

Monitor készítése pl. []g tulajdonsággal:
Monitor m = Monitor.getMonitor("[]g");

Feliratkozás a tulajdonság teljesülésére. Pl. kiíratjuk, hogy a tulajdonság teljesült:
m.acceptObservers.add((Runnable) () -> System.out.println("A tulajdonság teljesült."));

Tulajdonság sérüléséhez: m.rejectObservers

Event megadása, és monitor léptetése. Pl. g és end_of_trace:
m.move("g end_of_trace");
~~~~~~~~~~^
Az end_of_trace egy beépített jel. Eddig kell az ALWAYS és EVENTUALLY típusú követelményeknek teljesülniük.
Az eventeket szóközzel kell elválasztani.
A fölös szóközöket figyelmen kívül hagyja a program.

m.setAutomataToInitialState();
~~^ Visszaállítja az automaták kiinduló állapotát. (Mintha nem lett volna eddig 'move' hívás.)

Monitor.saveMonitor(m, "monitor.bin");
~~~~~~~~^ Az adott monitort az adott fájlba menti.

Monitor betöltése adott fájlból:
Monitor m = Monitor.loadMonitor("monitor.bin");

===================================================================================
Main:

LTL tulajdonságot kér ami alapján monitort készít.
Ha a tulajdonságot nem lehet lefordítani akkor hibára fut és kilép.

Eventeket kér, és lépteti a monitort.
Szól, ha olyan jel is meg van adva, amit a monitor nem ismer.
Szól, ha beolvasta az end_of_trace-t. A lépés befejeztével kilép.
Kiírja, ha a tulajdonság teljesült vagy sérült, majd kilép.

====================================================================================

amit az ltl2buchi-ben változtattam:
 - extra konstuktor a Guard-nak
 - G ψ ≡ false R ψ HELYETT G ψ ≡ end_of_trace R ψ
 - F ψ ≡ true U ψ HELYETT F ψ ≡ !end_of_trace U ψ