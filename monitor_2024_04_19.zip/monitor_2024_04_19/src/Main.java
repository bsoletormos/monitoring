import automaton.Monitor;
import gov.nasa.ltl.graph.Graph;
import gov.nasa.ltl.trans.ParseErrorException;

import java.io.*;

import static automaton.Monitor.*;

public class Main {
    public static void main(String[] args) {
/*
        Monitor<String> monitor;
        Monitor<String> monitor_copy;
        try {
            monitor = getMonitor("a U b");

            saveMonitor(monitor, "monitor.bin");

            monitor_copy = loadMonitor("monitor.bin");
        } catch (IOException | ClassNotFoundException | ParseErrorException e) {
            throw new RuntimeException(e);
        }

        assert monitor_copy != null;
        monitor_copy.acceptObservers.add(() -> System.out.println("A tulajdonság teljesült."));
        monitor_copy.rejectObservers.add(() -> System.out.println("A tulajdonság sérült."));
        monitor_copy.move("a");
        monitor_copy.move("");
*/
        System.out.print("LTL tulajdonság: ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Monitor m = null;
        try {
            m = getMonitor(br.readLine());
        } catch (ParseErrorException | IOException e) {
            System.err.println("Nem sikerült monitort készíteni a tulajdonságból.");
            System.exit(1);
        }
        m.rejectObservers.add((Runnable) () -> {
            System.out.println("A tulajdonság sérült.");
            System.exit(0);
        });
        m.acceptObservers.add((Runnable) () -> {
            System.out.println("A tulajdonság teljesült.");
            System.exit(0);
        });
        while (true) {
            try {
                System.out.print("Event: ");
                String event = br.readLine();
                if (event.contains("end_of_trace")) {
                    System.out.println("End of trace olvasva.");
                }
                m.move(event);
                if (event.contains("end_of_trace")) {
                    System.exit(0);
                }
            } catch (IOException e) {
                System.err.println("Nem sikerült beolvasni az event-et.");
                System.exit(1);
            }
        }
    }

/*    @SafeVarargs
    private static Guard<String> makeEvent(Literal<String>... literals) {
        Guard<String> result = new Guard<>();
        result.addAll(Arrays.asList(literals));
        return result;
    }

    private static Monitor<String> loadMonitor(String file) throws IOException, ClassNotFoundException {
        Monitor<String> monitor11;
        FileInputStream fileInputStream
                = new FileInputStream(file);
        ObjectInputStream objectInputStream
                = new ObjectInputStream(fileInputStream);
        //noinspection unchecked
        monitor11 = (Monitor<String>) objectInputStream.readObject();
        objectInputStream.close();
        return monitor11;
    }

    private static void saveMonitor(Monitor<String> monitor, String file) throws IOException {
        FileOutputStream fileOutputStream
                = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream
                = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(monitor);
        objectOutputStream.flush();
        objectOutputStream.close();
    }

    private static Monitor<String> getMonitor(String property) {
        Graph<String> g_accept;
        Graph<String> g_reject;
        try {
            g_accept = translate(property, true, true, true);
            g_reject = translate("!(%s)".formatted(property), true, true, true);
        } catch (ParseErrorException e) {
            throw new RuntimeException(e);
        }
        for (Node<String> node : new ArrayList<Node<String>>(){{addAll(g_reject.getNodes()); addAll(g_accept.getNodes());}}) {
            node.setBooleanAttribute("accepting", true);
        }
        return new Monitor<>(g_accept, g_reject);
    }*/
}