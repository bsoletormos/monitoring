package automaton;

import gov.nasa.ltl.graph.*;
import gov.nasa.ltl.trans.ParseErrorException;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import static gov.nasa.ltl.trans.LTL2Buchi.translate;

public class Monitor implements Serializable {
    Graph<String> accepting_graph;
    Graph<String> rejecting_graph;
    transient Set<String> signals;

    public final transient List<Runnable> acceptObservers = new ArrayList<>();
    private void notifyAcceptObservers() {
        acceptObservers.forEach(Runnable::run);
    }
    public final transient List<Runnable> rejectObservers = new ArrayList<>();
    private void notifyRejectObservers() {
        rejectObservers.forEach(Runnable::run);
    }

    public Monitor(Graph<String> accepting_graph, Graph<String> rejecting_graph) {
        this.accepting_graph = accepting_graph;
        this.rejecting_graph = rejecting_graph;
        setAutomataToInitialState();
        signals = new HashSet<>();
        for (Node<String> node : accepting_graph.getNodes()) {//félig kultúrált megoldás. A monitor nem fogja ismerni a kioptimalizált jeleket.
            for (Edge<String> edge : node.getOutgoingEdges()) {
                signals.addAll(edge.getGuard().stream().map(Literal::getAtom).collect(Collectors.toSet()));
            }
        }
        for (Node<String> node : rejecting_graph.getNodes()) {
            for (Edge<String> edge : node.getOutgoingEdges()) {
                signals.addAll(edge.getGuard().stream().map(Literal::getAtom).collect(Collectors.toSet()));
            }
        }
    }

    static class Automaton extends HashMap<Node<String>, Boolean> {
        public Set<Node<String>> nextStates(Collection<Literal<String>> event) {
            return entrySet().stream()
                    .filter(Map.Entry::getValue)
                    .map(Map.Entry::getKey)
                    .flatMap(node -> node.getOutgoingEdges().stream())
                    .filter(edge -> edge.getGuard().subtermOf(new Guard<>(event)))
                    .map(Edge::getNext)
                    .collect(Collectors.toSet());
        }

        public void setStates(Set<Node<String>> nextStates) {
            keySet().forEach(node -> put(node, nextStates.contains(node)));
        }
    }
    enum AutomatonID {ACCEPTING, REJECTING}
    transient Map<AutomatonID, Automaton> automata = new HashMap<>();
    {
        automata.put(AutomatonID.ACCEPTING, new Automaton());
        automata.put(AutomatonID.REJECTING, new Automaton());
    }

    //move, transition, step or advance
    private void moveWithLiterals(Collection<Literal<String>> eventLiterals) {
        automata.values().forEach(automaton -> automaton.setStates(automaton.nextStates(eventLiterals)));
        long accepting_automata_active_count = automata.get(AutomatonID.ACCEPTING).values().stream().filter(Boolean::booleanValue).count();
        long rejecting_automata_active_count = automata.get(AutomatonID.REJECTING).values().stream().filter(Boolean::booleanValue).count();
        if (accepting_automata_active_count == 0) {
            notifyRejectObservers();
        } else if (rejecting_automata_active_count == 0) {
            notifyAcceptObservers();
        }
    }

    public void move(String eventString) {
        eventString = eventString.trim();
        eventString = eventString.replaceAll("\\s+", " ");
        List<String> literals = new ArrayList<>(List.of(eventString.split(" "))); //active literals in the eventString
        if (literals.size() == 1 && literals.getFirst().isEmpty()) {
            literals.clear();
        }

        Guard<String> eventLiterals = new Guard<>();
        for (String signal : signals) { //all recognized signals
            eventLiterals.add(new Literal<>(signal, !literals.contains(signal)));
        }

        literals.removeAll(signals.stream().map(Object::toString).collect(Collectors.toSet()));
        for (String literal : literals) {
            System.out.println("Nincs ilyen jel: " + literal);
        }

        moveWithLiterals(eventLiterals);
    }

    public void setAutomataToInitialState() {
        for (Node<String> node : accepting_graph.getNodes()) {
            automata.get(AutomatonID.ACCEPTING).put(node, node == accepting_graph.getInit());
        }
        for (Node<String> node : rejecting_graph.getNodes()) {
            automata.get(AutomatonID.REJECTING).put(node, node == rejecting_graph.getInit());
        }
    }

    @Serial
    private void readObject(java.io.ObjectInputStream in)
            throws IOException, ClassNotFoundException {
        in.defaultReadObject();
    }

    @Serial
    private Object readResolve() {
        return new Monitor(accepting_graph, rejecting_graph);
    }

    public static Monitor loadMonitor(String file) throws IOException, ClassNotFoundException {
        Monitor monitor11;
        FileInputStream fileInputStream
                = new FileInputStream(file);
        ObjectInputStream objectInputStream
                = new ObjectInputStream(fileInputStream);
        monitor11 = (Monitor) objectInputStream.readObject();
        objectInputStream.close();
        return monitor11;
    }

    public static void saveMonitor(Monitor monitor, String file) throws IOException {
        FileOutputStream fileOutputStream
                = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream
                = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(monitor);
        objectOutputStream.flush();
        objectOutputStream.close();
    }

    public static Monitor getMonitor(String property) throws ParseErrorException {
        Graph<String> g_accept;
        Graph<String> g_reject;
        g_accept = translate(property, true, true, true);
        g_reject = translate("!(%s)".formatted(property), true, true, true);
        for (Node<String> node : new ArrayList<Node<String>>(){{addAll(g_reject.getNodes()); addAll(g_accept.getNodes());}}) {
            node.setBooleanAttribute("accepting", true);
        }
        return new Monitor(g_accept, g_reject);
    }
}
