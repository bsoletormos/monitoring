import automaton.Monitor;
import gov.nasa.ltl.graphio.Writer;
import gov.nasa.ltl.trans.*;

import java.io.*;
import java.util.List;

import static automaton.Monitor.*;

public class Main {
    public static void main(String[] args) {

        final boolean verbose;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Monitor m;
        System.out.print("LTL tulajdonság: ");
        try {
            String property = br.readLine();
            if (!property.contains("--verbose")) {
                verbose = false;
            } else {
                verbose = true;
                property = property.replace("--verbose", "");
            }
            property = Monitor.SERE.expandSereInProperty(property);
            if (verbose) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                Writer<String> writer = Writer.getWriter(Writer.Format.FSP, new PrintStream(bos)); //GraphWriter(Monitor, PrintStream)? GraphWriter.writeAccepting()

                Formula<String> original_formula = Parser.parse(property);
                System.out.println("Beolvasott tulajdonság: " + original_formula);
                Formula<String> formula = MyParser.parse(property);
                System.out.println("Beolvasott tulajdonság end_of_trace jellel: " + formula);
                System.out.print('\n');

                System.out.println("---- Elfogadó gráf: ----");
                Monitor m_original = getMonitor(property, Parser::parse);
                m_original.write(AcceptingID.ACCEPTING, writer);
                bos.flush();
                System.out.println(bos);
                bos.reset();

                System.out.println("---- Elutasító gráf: ----");
                m_original.write(AcceptingID.REJECTING, writer);
                bos.flush();
                System.out.println(bos);
                bos.reset();
            }
            m = getMonitor(property);
            if (verbose) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                Writer<String> writer = Writer.getWriter(Writer.Format.FSP, new PrintStream(bos));

                System.out.println("---- Elfogadó gráf end_of_trace jellel: ----");
                m.write(AcceptingID.ACCEPTING, writer);
                bos.flush();
                System.out.println(bos);
                bos.reset();

                System.out.println("---- Elutasító gráf end_of_trace jellel: ----");
                m.write(AcceptingID.REJECTING, writer);
                bos.flush();
                System.out.println(bos);
                bos.close();
            }
        } catch (ParseErrorException e) {
            System.out.println("Nem sikerült értelmezni a tulajdonságot.");
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        enum MonitorResult {
            ACCEPTED("A tulajdonság teljesült."), REJECTED("A tulajdonság sérült."), UNDECIDED("");
            final String message;
            MonitorResult(String message) {
                this.message = message;
            }
        }
        final MonitorResult[] monitorResult = {MonitorResult.UNDECIDED};
        m.acceptObservers.add(() -> monitorResult[0] = MonitorResult.ACCEPTED);
        m.rejectObservers.add(() -> monitorResult[0] = MonitorResult.REJECTED);

        while (true) {
            System.out.print("Esemény(ek): ");
            try {
                List<String> events = parseEvents(br.readLine());
                boolean multiple_events = events.size() > 1;
                for (String event : events) {
                    if (multiple_events || verbose) {
                        System.out.println("esemény: " + event);
                    }
                    m.move(event);
                    if (verbose) {
                        for (AcceptingID id : AcceptingID.values()) {
                            System.out.print(id.name().toLowerCase() + ": ");
                            m.getAutomatonState(id).stream().map(s -> s + " ").sorted().forEachOrdered(System.out::print);
                            System.out.print('\n');
                        }
                        System.out.print('\n');
                    }
                    boolean done = false;
                    if (monitorResult[0] != MonitorResult.UNDECIDED) {
                        done = true;
                        System.out.println(monitorResult[0].message);
                    }
                    if (event.contains("end_of_trace")) {
                        done = true;
                        System.out.println("END OF TRACE");
                    }
                    if (done) {
                        System.exit(0);
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (IllegalArgumentException e) {
                System.out.println("Nem sikerült értelmezni az esemény(ek)et: " + e.getMessage());
                continue;
            }
        }
    }
}