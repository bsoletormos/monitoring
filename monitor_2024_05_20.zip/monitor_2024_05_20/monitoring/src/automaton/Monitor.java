package automaton;

import gov.nasa.ltl.graph.*;
import gov.nasa.ltl.graphio.Writer;
import gov.nasa.ltl.trans.Formula;
import gov.nasa.ltl.trans.MyParser;
import gov.nasa.ltl.trans.ParseErrorException;
import gov.nasa.ltl.trans.Parser;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static gov.nasa.ltl.trans.LTL2Buchi.translate;

public class Monitor implements Serializable {
    Graph<String> accepting_graph;
    Graph<String> rejecting_graph;
    transient Set<String> signals;
    transient Set<String> accepting_signals;
    transient Set<String> rejecting_signals;

    public final transient List<Runnable> acceptObservers = new ArrayList<>();
    private void notifyAcceptObservers() {
        acceptObservers.forEach(Runnable::run);
    }
    public final transient List<Runnable> rejectObservers = new ArrayList<>();
    private void notifyRejectObservers() {
        rejectObservers.forEach(Runnable::run);
    }

    private Monitor(Graph<String> accepting_graph, Graph<String> rejecting_graph) {
        this.accepting_graph = accepting_graph;
        this.rejecting_graph = rejecting_graph;
        this.acceptingAutomaton = new Automaton();
        this.rejectingAutomaton = new Automaton();
        setAutomataToInitialState();
        this.signals = new HashSet<>();
        this.accepting_signals = new HashSet<>();
        this.rejecting_signals = new HashSet<>();
        parseAndAddSignals();
    }

    private void parseAndAddSignals() {//helper
        for (AcceptingID id : AcceptingID.values()) {
            final Set<String> exclusive_signals = getSignalsByID(id);
            getGraphByID(id).getNodes().stream()
                .flatMap(stringNode -> stringNode.getOutgoingEdges().stream())
                .map(Edge::getGuard)
                .flatMap(Guard::stream)
                .map(Literal::getAtom)
                .forEach(s -> {
                    signals.add(s);
                    exclusive_signals.add(s);
                });
        }
    }

    static class Automaton extends HashMap<Node<String>, Boolean> {
        public Set<Node<String>> nextStates(Collection<Literal<String>> event) {
            return entrySet().stream()
                    .filter(Entry::getValue)
                    .map(Entry::getKey)
                    .flatMap(node -> node.getOutgoingEdges().stream())
                    .filter(edge -> edge.getGuard().subtermOf(new Guard<>(event)))
                    .map(Edge::getNext)
                    .collect(Collectors.toSet());
        }

        public void setStates(Set<Node<String>> nextStates) {
            keySet().forEach(node -> put(node, nextStates.contains(node)));
        }
    }
    transient Automaton acceptingAutomaton;
    transient Automaton rejectingAutomaton;

    public void setAutomataToInitialState() {
        for (AcceptingID id : AcceptingID.values()) {
            for (Node<String> node : getGraphByID(id).getNodes()) {
                getAutomatonByID(id).put(node, node == getGraphByID(id).getInit());
            }
        }
    }

    @Serial
    private void readObject(ObjectInputStream in)
            throws IOException, ClassNotFoundException {
        in.defaultReadObject();
    }

    @Serial
    private Object readResolve() {
        return new Monitor(accepting_graph, rejecting_graph);
    }

    public static Monitor loadMonitor(String file) throws IOException, ClassNotFoundException {
        Monitor monitor11;
        FileInputStream fileInputStream
                = new FileInputStream(file);
        ObjectInputStream objectInputStream
                = new ObjectInputStream(fileInputStream);
        monitor11 = (Monitor) objectInputStream.readObject();
        objectInputStream.close();
        return monitor11;
    }

    public static void saveMonitor(Monitor monitor, String file) throws IOException {
        FileOutputStream fileOutputStream
                = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream
                = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(monitor);
        objectOutputStream.flush();
        objectOutputStream.close();
    }

    @FunctionalInterface
    public interface ParserFunction {//helper
        Formula<String> parse(String property) throws ParseErrorException;
    }

    public static Monitor getMonitor(String property, ParserFunction parseFunction) throws ParseErrorException {//special case
        Graph<String> g_accept;
        Graph<String> g_reject;
        g_accept = translate(parseFunction.parse(property), true, true, true);
        g_reject = translate(parseFunction.parse("!(%s)".formatted(property)), true, true, true);
        //set all to accepting?
        return new Monitor(g_accept, g_reject);
    }

    public static Monitor getMonitor(String property) throws ParseErrorException {
        return getMonitor(property, MyParser::parse);
    }

    public enum AcceptingID {
        ACCEPTING, REJECTING
    }
    private Graph<String> getGraphByID(AcceptingID graphID) {
        return switch (graphID) {
            case ACCEPTING -> accepting_graph;
            case REJECTING -> rejecting_graph;
        };
    }
    private Automaton getAutomatonByID(AcceptingID automatonID) {
        return switch (automatonID) {
            case ACCEPTING -> acceptingAutomaton;
            case REJECTING -> rejectingAutomaton;
        };
    }
    private Set<String> getSignalsByID(AcceptingID id) {
        return switch (id) {
            case ACCEPTING -> accepting_signals;
            case REJECTING -> rejecting_signals;
        };
    }

    public void move(String eventsString) {
        for (String event : parseEvents(eventsString)) {
            moveWithSingleStringEvent(event);
        }
    }

    public Set<String> getAutomatonState(AcceptingID automatonID) {
        return getAutomatonByID(automatonID).entrySet().stream()
                .filter(Map.Entry::getValue)
                .map(Map.Entry::getKey)
                .map(Node::getId)
                .map(integer -> "S" + integer)
                .collect(Collectors.toSet());
    }

    private void moveWithSingleStringEvent(String eventString) {
        eventString = eventString.trim();
        eventString = eventString.replaceAll("\\s+", " ");
        List<String> eventSignals = new ArrayList<>();
        if (!eventString.isEmpty()) {
            Collections.addAll(eventSignals, eventString.split(" "));
        }
        for (String signal : eventSignals) {
            if (!signals.contains(signal)) {
                System.out.println("Nincs ilyen jel: " + signal);
            }
        }
        for (AcceptingID id : AcceptingID.values()) {
            Set<String> exclusiveSignals = getSignalsByID(id);
            Automaton a = getAutomatonByID(id);
            a.setStates(a.nextStates(exclusiveSignals.stream()
                    .map(s -> new Literal<>(s, !eventSignals.contains(s)))
                    .collect(Collectors.toSet())));
        }
        if (acceptingAutomaton.values().stream().noneMatch(Boolean::booleanValue) && rejectingAutomaton.values().stream().noneMatch(Boolean::booleanValue)) {
            throw new IllegalStateException("Both automata have failed; contradiction.");
        }
        if (acceptingAutomaton.values().stream().noneMatch(Boolean::booleanValue)) {
            notifyRejectObservers();
        }
        if (rejectingAutomaton.values().stream().noneMatch(Boolean::booleanValue)) {
            notifyAcceptObservers();
        }
    }

    public void write(AcceptingID graphID, Writer<String> writer) {
        writer.write(getGraphByID(graphID));
    }

    public static List<String> parseEvents(String eventsString) {
        List<String> events = new ArrayList<>();
        eventsString = eventsString.trim();
        eventsString = eventsString.replaceAll("\\s+", " ");
        if (eventsString.isEmpty()) {
            events.add("");
            return events;
        }

        String noBrackets = "^[^{}]*$"; //no brackets
        if (eventsString.matches(noBrackets)) {
            events.add(eventsString);
            return events;
        }
        String legalBrackets = "^(\\{[^{}]*}\\s*)*$"; //balanced, non-nested pairs of brackets with only space between.
        if (eventsString.matches(legalBrackets)) {
            String bracketed = "\\{[^{}]*}";
            Matcher matcher = Pattern.compile(bracketed).matcher(eventsString);
            while (matcher.find()) {
                events.add(matcher.group().replaceAll("[{}]", "").trim());
            }
            return events;
        }
        throw new IllegalArgumentException("Invalid events string: " + eventsString);
    }

    public static class SERE {
        private static class Repetition {
            public String event;
            public int min;
            public int max; //0 means uncapped
        }
        public static String expandSereInProperty(String property) {

            final String original_property = property;
            property = property.trim().replaceAll("\\s+", " ");
            if (property.isEmpty()) return "";

            if (property.matches("^[^{}]*$")) {
                return property;
            }

            {
                Matcher m = Pattern.compile("\\{[^{}]*\\{").matcher(property);
                if (m.find()) {
                    throw new IllegalArgumentException("Váratlan nyitó kapcsos zárójel: " + m.group());
                }
                m = Pattern.compile("(^|})[^{}]*}").matcher(property);
                if (m.find()) {
                    throw new IllegalArgumentException("Váratlan záró kapcsos zárójel: " + m.group());
                }
            }

            StringBuilder result = new StringBuilder();
            Matcher m_sere = Pattern.compile("(?<ltl>[^{}]*)\\{(?<sere>[^{}]*)}").matcher(property);
            int last_match_end = 0;
            while (m_sere.find()) {
                last_match_end = m_sere.end();
                result.append(m_sere.group("ltl"));
                String sere = m_sere.group("sere").trim();
                String[] regexes = getRegexesFromSere(sere, original_property);
                List<Repetition> repetitions = new ArrayList<>();
                for (String regex : regexes) {
                    Repetition repetition = getRepetitionFromRegex(regex, original_property);
                    repetitions.add(repetition);
                }
                result.append(repetitionsToLtl(repetitions));
            }
            result.append(property.substring(last_match_end));
            return result.toString();
        }

        private static Repetition getRepetitionFromRegex(String regex, String original_property) {
            Repetition repetition = new Repetition();
            Matcher m_regex = Pattern.compile("^(?<prefix>[^*?+\\[\\],;]*)(?<postfix>[*?+]|\\[ ?(?<min>\\d+)( ?, ?(?<max>\\d+|\\*))? ?])?$").matcher(regex);
            if (!m_regex.find()) {
                throw new IllegalArgumentException("Nem sikerült értelmezni egy reguáris kifejezést: " + regex);
            }
            repetition.event = m_regex.group("prefix").trim();
            if (repetition.event.isEmpty()) {
                throw new IllegalArgumentException("Nem sikerült jelet találni egy reguláris kifejezésben: " + regex);
            }
            if (m_regex.group("postfix") == null) { //there is no postfix: {a} => repeat exactly once
                repetition.min = 1;
                repetition.max = 1;
            } else switch (m_regex.group("postfix")) { //there is a postfix: * ? + [n] [n,m] [n,*]
                case "*":
                    repetition.min = 0;
                    repetition.max = 0;
                    break;
                case "?":
                    repetition.min = 0;
                    repetition.max = 1;
                    break;
                case "+":
                    repetition.min = 1;
                    repetition.max = 0;
                    break;
                default: //[n] [n,m] [n,*]
                    repetition.min = Integer.parseInt(m_regex.group("min"));
                    if (m_regex.group("max") == null) { //[n]
                        repetition.max = repetition.min;
                    } else if (m_regex.group("max").equals("*")) { //[n,*]
                        repetition.max = 0;
                    } else { //[n,m]
                        repetition.max = Integer.parseInt(m_regex.group("max"));
                        if (repetition.max < repetition.min) throw new IllegalArgumentException("Repetition upper bound is smaller than the lower bound: " + original_property);
                        if (repetition.max == 0) throw new IllegalArgumentException("Repetition upper bound is zero: " + original_property);
                    }
            }
            return repetition;
        }

        private static String[] getRegexesFromSere(String sere, String original_property) {
            if (sere.isEmpty()) throw new IllegalArgumentException("Üres SERE a tulajdonságban: " + original_property);
            String[] regexes = sere.split(";");
            for (int i = 0; i < regexes.length; i++) {
                regexes[i] = regexes[i].trim();
                if (regexes[i].isEmpty()) throw new IllegalArgumentException("Üres reguláris kifejezés egy SERE-ben: " + sere);
            }
            return regexes;
        }

        private static String repetitionsToLtl(List<Repetition> repetitions) {
            assert !repetitions.isEmpty();

            int last = repetitions.size() - 1;
            while (last >= 0) {
                Repetition repetition = repetitions.get(last);
                if (repetition.min != 0) {
                    break;
                }
                last--;
            }
            if (last < 0) {
                return "(true)";
            }

            String result; //ltl

            {
                Repetition repetition = repetitions.get(last);
                String format = "(%1$s)" + "&&(X((%1$s)".repeat(repetition.min - 1) +
                        "))".repeat(repetition.min - 1);
                result = format.formatted(repetition.event);
            }

            for (int i = last - 1; i >= 0; i--) {
                Repetition repetition = repetitions.get(i);
                result = repetitionToLtl_getFormat(repetition).formatted(repetition.event, result);
            }

            return "(" + result + ")";
        }

        private static String repetitionToLtl_getFormat(Repetition repetition) {
            StringBuilder format = new StringBuilder();
            int parentheses = 0;
            if (repetition.min != 0) {
                format.append("(%1$s)&&(X(".repeat(repetition.min));
                parentheses += (repetition.min) * 2;
            }
            if (repetition.max == 0) {
                format.append("(%1$s)U(%2$s)");
            }
            if (repetition.max != 0) {
                format.append("(%2$s)");
                format.append("||(%1$s)&&(X((%2$s)".repeat(repetition.max - repetition.min));
                parentheses += (repetition.max - repetition.min) * 2;
            }
            format.append(")".repeat(parentheses));
            return format.toString();
        }
    } //public static class SERE
}
