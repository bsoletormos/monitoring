TARTALOM:
monitor_readme.txt
monitoring/src/
monitoring/out/artifacts/monitoring.jar
monitoring/out/production/monitoring/ 		--(class fájlok)
buchi/ltl2buchi_Readme.txt 			--(Leírja a tulajdonságok elvárt alakját.)
						--Különbség: Az UNTIL, EVENTUALLY, GLOBALLY és NEXT mind támogatják az end_of_trace tulajdonságot.
buchi/src/
buchi/ltl2buchi.jar
buchi/build/gov/nasa/ltl/ 			--(class fájlok)

===========================================================================
monitoring/monitoring/Main.class 		--demó program

1. Az program beolvassa a tulajdonságot. Elkészíti a monitort.
	{}-párok közt használható SERE kifejezés.
		Támogatott operátorok az eseményekhez: ; ? * + [n] [n,m] [n,*]
		Az üres SERE nem elfogadott.
		A pontos vessző az utolsó kifejezés után alapvetően nem támogatott.
		A SERE réteg nem ellenőrzi az események helyességét. Ha az események helytelenek, akkor zagyva ltl keletkezik, amit nem sikerül lefordítani.
	Használhatunk --verbose kapcsolót.
		Ha nem választjuk el a --verbose kapcsolót szóközökkel, az alapvetően nem támogatott.

2. Ha használtuk a --verbose kapcsolót:
	Ekkor a program zárójelezve kiírja az eredeti és a negált tulajdonságot; end_of_trace jellel és anélkül is.
		Előjöhetnek ezek az operátorok, amiket az ltl2buchi nem említ a readme-jében, csak a kódjában (amennyire én tudom):
		 - 'W': // weak until
		 - 'V': // release
		 - 'M': // dual of W - weak release
	Kiírja a hozzájuk tartozó Büchi automatákat is.
		Ehhez az ltl2buchi FSP típusú Writer-ét használja.

3. A program eseményt/eseményeket olvas be.
	Szóközzel elválasztva lehet az aktív jeleket megadni.
	{}-párok közt több eseményt is meg lehet adni.
	end_of_trace jellel lehet az eseménysorozat végét jelölni. --(Az igazi magyaros kifejezés a 'trace' szóra pillanatnyilag nem jut eszembe :[ )

4. A program egyenként átadja az eseményeket a monitornak.
	Ha több eseményt is megadtunk, vagy a verbose mód be van kapcsolva: sorról sorra kiírja, hogy melyik eseménynél tart.
	Ha valamelyik jel nem szerepel a monitorban, akkor a monitor jelzi azt.
	Ha a --verbose be van kapcsolva, akkor a program kiírja az automaták aktív állapotait. (Más szóval az aktív csomópontokat.)
	Ha a tulajdonság teljesült vagy sérült, akkor a program kiírja ezt, és ki fog lépni.
	Ha a program beolvasta az end_of_trace-t akkor végül kilép.

===========================================================================

Monitor készítése pl. []g tulajdonsággal:
Monitor m = Monitor.getMonitor("[]g");

>Az ltl2buchi által elvárt formában kell megadni.

Feliratkozás a tulajdonság teljesülésére. Pl. kiíratjuk, hogy a tulajdonság teljesült:
m.acceptObservers.add(() -> System.out.println("A tulajdonság teljesült."));

>Tulajdonság sérüléséhez: m.rejectObservers

Event megadása, és monitor léptetése. Pl. g és end_of_trace:
m.move("g end_of_trace");
~~~~~~~~~~^
Az end_of_trace egy beépített jel. Eddig kell az ALWAYS, UNTIL és EVENTUALLY típusú követelményeknek teljesülniük.
Az eventeket szóközzel kell elválasztani.
A fölös szóközöket figyelmen kívül hagyja a program.

Több event megadása:
m.move("{g} {g end_of_trace}");

m.setAutomataToInitialState();
~~^ Visszaállítja az automaták kiinduló állapotát. (Mintha nem lett volna eddig 'move' hívás.)

Monitor.saveMonitor(m, "monitor.bin");
~~~~~~~~^ Az adott monitort az adott fájlba menti.

Monitor betöltése adott fájlból:
Monitor m = Monitor.loadMonitor("monitor.bin");

====================================================================================

amit az ltl2buchi-ben változtattam:
 - extra konstuktor a Guard-nak
 - Graph és tagjai: Seriablizable
 - G ψ ≡ false R ψ HELYETT end_of_trace R ψ
~~~~~~~~~~~~~~~^ Release operátor
 - F ψ ≡ true U ψ HELYETT !end_of_trace U ψ
 - ψ U φ HELYETT (ψ ∧ !end_of_trace) U φ